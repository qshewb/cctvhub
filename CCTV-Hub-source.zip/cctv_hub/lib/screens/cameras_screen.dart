import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../store.dart';
import '../widgets/common.dart';
import '../widgets/live_tile.dart';
import 'add_account_screen.dart';
import 'camera_view_screen.dart';
import 'gallery_screen.dart';

class CamerasScreen extends StatelessWidget {
  const CamerasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final cams = s.cameras;
    final online = cams.where((c) => c.online).length;

    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Kamera'),
          Text('$online dari ${cams.length} online',
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Tata letak',
            icon: Icon(s.gridColumns == 1
                ? Icons.view_agenda_outlined
                : s.gridColumns == 2
                    ? Icons.grid_view_rounded
                    : Icons.apps_rounded),
            onPressed: () => s.setColumns(s.gridColumns % 3 + 1),
          ),
          IconButton(
            tooltip: 'Galeri',
            icon: const Icon(Icons.photo_library_outlined),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const GalleryScreen())),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: s.refresh,
        child: cams.isEmpty
            ? ListView(children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7,
                  child: s.loading
                      ? const Center(child: CircularProgressIndicator())
                      : EmptyState(
                          icon: Icons.videocam_rounded,
                          title: 'Belum ada kamera',
                          message:
                              'Tambahkan akun Bardi, Smart Life, atau kamera Yoosee, V380, Eyesec dan lainnya.',
                          action: 'Tambah akun',
                          onAction: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => const AddAccountScreen())),
                        ),
                ),
              ])
            : GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: s.gridColumns,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: s.gridColumns == 1 ? 16 / 9 : 4 / 3,
                ),
                itemCount: cams.length,
                itemBuilder: (_, i) {
                  final d = cams[i];
                  return LiveTile(
                    key: ValueKey('${d.accountId}/${d.id}'),
                    device: d,
                    // batasi jumlah stream bersamaan agar HP tidak berat
                    live: s.livePreview && d.online && i < 6,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => CameraViewScreen(device: d)),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
