import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../brands.dart';
import '../models.dart';
import '../services/onvif.dart';
import '../store.dart';
import '../widgets/common.dart';

class AddCameraScreen extends StatefulWidget {
  final String accountId;
  final LocalCamera? existing;
  const AddCameraScreen({super.key, required this.accountId, this.existing});

  @override
  State<AddCameraScreen> createState() => _AddCameraScreenState();
}

class _AddCameraScreenState extends State<AddCameraScreen> {
  late Brand brand;
  late final TextEditingController name, host, rtsp, onvifPort, user, pass, mainPath, subPath;
  bool useOnvif = true;
  bool hide = true;
  bool testing = false;
  String? testResult;
  bool advanced = false;

  @override
  void initState() {
    super.initState();
    final acc = context.read<AppStore>().account(widget.accountId);
    brand = brandById(acc?.brandId ?? 'generic');
    final e = widget.existing;
    name = TextEditingController(text: e?.name ?? 'Kamera ${brand.name}');
    host = TextEditingController(text: e?.host ?? '192.168.1.');
    rtsp = TextEditingController(text: '${e?.rtspPort ?? brand.rtspPort}');
    onvifPort = TextEditingController(text: '${e?.onvifPort ?? brand.onvifPort}');
    user = TextEditingController(text: e?.username ?? brand.defaultUser);
    pass = TextEditingController(text: e?.password ?? '');
    mainPath = TextEditingController(text: e?.mainPath ?? brand.mainPath);
    subPath = TextEditingController(text: e?.subPath ?? brand.subPath);
    useOnvif = e?.useOnvif ?? true;
  }

  LocalCamera _build() => LocalCamera(
        id: widget.existing?.id ?? newId(),
        name: name.text.trim().isEmpty ? 'Kamera' : name.text.trim(),
        host: host.text.trim(),
        rtspPort: int.tryParse(rtsp.text) ?? 554,
        onvifPort: int.tryParse(onvifPort.text) ?? 80,
        username: user.text.trim(),
        password: pass.text,
        mainPath: mainPath.text.trim().isEmpty ? '/' : mainPath.text.trim(),
        subPath: subPath.text.trim(),
        useOnvif: useOnvif,
      );

  Future<void> _test() async {
    final c = _build();
    if (c.host.isEmpty) return;
    setState(() {
      testing = true;
      testResult = null;
    });
    final lines = <String>[];
    try {
      final s = await Socket.connect(c.host, c.rtspPort, timeout: const Duration(seconds: 4));
      s.destroy();
      lines.add('✓ Port RTSP ${c.rtspPort} terbuka');
    } catch (_) {
      lines.add('✗ Port RTSP ${c.rtspPort} tidak bisa dijangkau');
    }
    if (useOnvif) {
      try {
        final o = OnvifClient(c);
        final uri = await o.streamUri();
        lines.add(uri != null ? '✓ ONVIF OK${o.hasPtz ? ' · PTZ tersedia' : ''}' : '✗ ONVIF: profil tidak ditemukan');
        if (uri != null && (c.mainPath == '/' || c.mainPath.isEmpty)) {
          final u = Uri.parse(uri);
          mainPath.text = u.hasQuery ? '${u.path}?${u.query}' : u.path;
          lines.add('→ Jalur stream terdeteksi otomatis');
        }
      } catch (e) {
        lines.add('✗ ${e.toString().replaceFirst('Exception: ', '')}');
      }
    }
    if (mounted) {
      setState(() {
        testing = false;
        testResult = lines.join('\n');
      });
    }
  }

  Future<void> _save() async {
    final c = _build();
    if (c.host.isEmpty || c.host.endsWith('.')) return toast(context, 'Alamat IP belum lengkap');
    await context.read<AppStore>().saveCamera(widget.accountId, c);
    if (mounted) {
      Navigator.pop(context);
      toast(context, 'Kamera tersimpan');
    }
  }

  Widget _field(TextEditingController c, String label,
      {TextInputType? type, bool obscure = false, Widget? suffix, String? helper}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        keyboardType: type,
        obscureText: obscure,
        decoration: InputDecoration(labelText: label, suffixIcon: suffix, helperText: helper),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'Tambah kamera' : 'Ubah kamera')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (brand.hint.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: cs.primary.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14)),
            child: Text(brand.hint, style: const TextStyle(fontSize: 13, height: 1.4)),
          ),
        _field(name, 'Nama kamera (mis. Teras)'),
        _field(host, 'Alamat IP kamera', type: TextInputType.url,
            helper: 'Lihat di aplikasi bawaan atau router. Bisa juga domain DDNS.'),
        _field(user, 'Username'),
        _field(pass, 'Password',
            obscure: hide,
            suffix: IconButton(
              icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
              onPressed: () => setState(() => hide = !hide),
            )),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Gunakan ONVIF'),
          subtitle: const Text('Deteksi stream otomatis + kontrol PTZ'),
          value: useOnvif,
          onChanged: (v) => setState(() => useOnvif = v),
        ),
        TextButton.icon(
          style: TextButton.styleFrom(alignment: Alignment.centerLeft, padding: EdgeInsets.zero),
          onPressed: () => setState(() => advanced = !advanced),
          icon: Icon(advanced ? Icons.expand_less_rounded : Icons.expand_more_rounded),
          label: const Text('Pengaturan lanjutan'),
        ),
        if (advanced) ...[
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _field(rtsp, 'Port RTSP', type: TextInputType.number)),
            const SizedBox(width: 12),
            Expanded(child: _field(onvifPort, 'Port ONVIF', type: TextInputType.number)),
          ]),
          _field(mainPath, 'Jalur stream utama (HD)', helper: 'Isi "/" agar dideteksi lewat ONVIF'),
          _field(subPath, 'Jalur substream (SD)'),
        ],
        if (testResult != null)
          Container(
            margin: const EdgeInsets.only(top: 8, bottom: 8),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: cs.surfaceContainer, borderRadius: BorderRadius.circular(14)),
            child: Text(testResult!, style: const TextStyle(height: 1.6, fontSize: 13)),
          ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: testing ? null : _test,
          icon: testing
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.wifi_tethering_rounded),
          label: const Text('Tes koneksi'),
        ),
        const SizedBox(height: 12),
        FilledButton(onPressed: _save, child: const Text('Simpan kamera')),
      ]),
    );
  }
}
