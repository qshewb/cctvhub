import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';

import '../brands.dart';
import '../models.dart';
import '../services/media_store.dart';
import '../services/onvif.dart';
import '../services/stream.dart';
import '../store.dart';
import '../widgets/common.dart';
import '../widgets/device_controls.dart';
import '../widgets/ptz_pad.dart';
import 'add_camera_screen.dart';

class CameraViewScreen extends StatefulWidget {
  final Device device;
  const CameraViewScreen({super.key, required this.device});

  @override
  State<CameraViewScreen> createState() => _CameraViewScreenState();
}

class _CameraViewScreenState extends State<CameraViewScreen> {
  late final Player player = Player();
  late final VideoController controller = VideoController(player);

  bool muted = true;
  bool hd = true;
  bool full = false;
  bool playing = false;
  String? error;

  bool recording = false;
  DateTime? recStart;
  Timer? recTimer;

  OnvifClient? onvif;
  bool onvifPtz = false;
  bool tuyaPtz = false;

  Device get d => widget.device;

  @override
  void initState() {
    super.initState();
    player.stream.playing.listen((v) => mounted ? setState(() => playing = v) : null);
    player.stream.error.listen((e) => mounted ? setState(() => error = 'Stream terputus') : null);
    _open();
    if (d.local != null && d.local!.useOnvif) {
      onvif = OnvifClient(d.local!);
      onvif!.checkPtz().then((v) => mounted ? setState(() => onvifPtz = v) : null);
    }
  }

  Future<void> _open() async {
    setState(() {
      error = null;
      playing = false;
    });
    try {
      await tunePlayer(player);
      await player.setVolume(muted ? 0 : 100);
      final url = await resolveStream(context.read<AppStore>(), d, sub: !hd);
      await player.open(Media(url));
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  @override
  void dispose() {
    recTimer?.cancel();
    if (recording) _setRecord(false);
    player.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // ---------- aksi ----------
  Future<void> _snapshot() async {
    final bytes = await player.screenshot();
    if (bytes == null) {
      if (mounted) toast(context, 'Belum ada gambar untuk diambil');
      return;
    }
    await MediaStore.saveSnapshot(d.name, bytes);
    HapticFeedback.mediumImpact();
    if (mounted) toast(context, 'Snapshot disimpan ke Galeri');
  }

  Future<void> _setRecord(bool on) async {
    if (player.platform is! NativePlayer) return;
    final dynamic n = player.platform;
    if (on) {
      final path = await MediaStore.newRecordingPath(d.name);
      await n.setProperty('stream-record', path);
      recStart = DateTime.now();
      recTimer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() {}));
    } else {
      await n.setProperty('stream-record', '');
      recTimer?.cancel();
    }
    if (mounted) {
      setState(() => recording = on);
      if (!on) toast(context, 'Rekaman disimpan ke Galeri');
    }
  }

  void _toggleFull() {
    setState(() => full = !full);
    if (full) {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      Future.delayed(const Duration(milliseconds: 600),
          () => SystemChrome.setPreferredOrientations(DeviceOrientation.values));
    }
  }

  // PTZ
  void _move(int dx, int dy) {
    HapticFeedback.selectionClick();
    if (onvifPtz) {
      onvif!.move(dx * 0.5, dy * 0.5).catchError((_) {});
    } else if (tuyaPtz) {
      const map = {'0,1': '0', '1,0': '2', '0,-1': '4', '-1,0': '6'};
      context.read<AppStore>().tuya(d.accountId).command(d.id, 'ptz_control', map['$dx,$dy']).catchError((_) {});
    }
  }

  void _stopMove() {
    if (onvifPtz) {
      onvif!.stop().catchError((_) {});
    } else if (tuyaPtz) {
      context.read<AppStore>().tuya(d.accountId).command(d.id, 'ptz_stop', true).catchError((_) {});
    }
  }

  String get _recElapsed {
    final s = DateTime.now().difference(recStart ?? DateTime.now()).inSeconds;
    return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
  }

  // ---------- UI ----------
  Widget _video() {
    return Container(
      color: Colors.black,
      child: Stack(fit: StackFit.expand, children: [
        Video(controller: controller, controls: NoVideoControls, fit: BoxFit.contain),
        if (!playing && error == null)
          const Center(child: CircularProgressIndicator(color: Colors.white70, strokeWidth: 2)),
        if (error != null)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.videocam_off_rounded, color: Colors.white54, size: 36),
                const SizedBox(height: 8),
                Text(error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70, fontSize: 13)),
                TextButton(onPressed: _open, child: const Text('Muat ulang')),
              ]),
            ),
          ),
        if (recording)
          Positioned(
            top: 12,
            left: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(8)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.fiber_manual_record, size: 10, color: Colors.white),
                const SizedBox(width: 6),
                Text('REC $_recElapsed',
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
              ]),
            ),
          ),
        if (full)
          Positioned(
            right: 12,
            bottom: 12,
            child: Row(children: [
              _glass(muted ? Icons.volume_off_rounded : Icons.volume_up_rounded, _toggleMute),
              _glass(Icons.photo_camera_rounded, _snapshot),
              _glass(Icons.fullscreen_exit_rounded, _toggleFull),
            ]),
          ),
      ]),
    );
  }

  Widget _glass(IconData i, VoidCallback f) => Padding(
        padding: const EdgeInsets.only(left: 8),
        child: Material(
          color: Colors.black45,
          shape: const CircleBorder(),
          child: IconButton(onPressed: f, icon: Icon(i, color: Colors.white)),
        ),
      );

  void _toggleMute() {
    setState(() => muted = !muted);
    player.setVolume(muted ? 0 : 100);
  }

  Widget _action(IconData icon, String label, VoidCallback onTap, {bool active = false, Color? color}) {
    final cs = Theme.of(context).colorScheme;
    final c = color ?? (active ? cs.primary : cs.onSurface);
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: active ? c.withValues(alpha: 0.15) : cs.surfaceContainer,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(icon, color: c),
            ),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (full) {
      return PopScope(
        canPop: false,
        onPopInvokedWithResult: (_, __) => _toggleFull(),
        child: Scaffold(backgroundColor: Colors.black, body: _video()),
      );
    }

    final s = context.watch<AppStore>();
    final acc = s.account(d.accountId);
    final brand = brandById(acc?.brandId ?? 'generic');
    final fav = s.favorites.contains(d.id);
    final hasPtz = onvifPtz || tuyaPtz;

    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(d.name, style: const TextStyle(fontSize: 18)),
          Row(children: [
            StatusDot(d.online),
            const SizedBox(width: 6),
            Text('${brand.name} · ${acc?.name ?? ''}',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ]),
        ]),
        actions: [
          IconButton(
            icon: Icon(fav ? Icons.star_rounded : Icons.star_outline_rounded,
                color: fav ? const Color(0xFFFBBF24) : null),
            onPressed: () => s.toggleFavorite(d.id),
          ),
          if (d.local != null)
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () async {
                await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => AddCameraScreen(accountId: d.accountId, existing: d.local)));
                if (mounted) Navigator.pop(context);
              },
            ),
        ],
      ),
      body: ListView(padding: EdgeInsets.zero, children: [
        AspectRatio(aspectRatio: 16 / 9, child: _video()),
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 12, 8, 4),
          child: Row(children: [
            _action(muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                muted ? 'Suara' : 'Bisukan', _toggleMute, active: !muted),
            _action(Icons.photo_camera_rounded, 'Snapshot', _snapshot),
            _action(recording ? Icons.stop_rounded : Icons.fiber_manual_record_rounded,
                recording ? _recElapsed : 'Rekam', () => _setRecord(!recording),
                active: recording, color: recording ? Colors.red : null),
            _action(hd ? Icons.hd_rounded : Icons.sd_rounded, hd ? 'HD' : 'SD', () {
              setState(() => hd = !hd);
              _open();
            }, active: hd),
            _action(Icons.fullscreen_rounded, 'Layar penuh', _toggleFull),
          ]),
        ),
        if (hasPtz) ...[
          const SectionLabel('Kontrol arah (PTZ)'),
          PtzPad(
            onMove: _move,
            onStop: _stopMove,
            onZoom: onvifPtz ? (z) => onvif!.move(0, 0, zoom: z * 0.5).catchError((_) {}) : null,
          ),
          if (onvifPtz) ...[
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  for (var i = 1; i <= 4; i++)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: OutlinedButton(
                          onPressed: () => onvif!.gotoPreset(i).catchError((_) {}),
                          onLongPress: () async {
                            await onvif!.setPreset(i).catchError((_) {});
                            if (mounted) toast(context, 'Posisi $i disimpan');
                          },
                          child: Text('P$i'),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('Tekan lama tombol P untuk menyimpan posisi',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 11.5, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          ],
        ],
        if (d.isTuya) ...[
          const SectionLabel('Fitur kamera'),
          DeviceControls(
            device: d,
            onLoaded: (f) {
              final ptz = f.any((e) => e.code == 'ptz_control');
              if (ptz != tuyaPtz && mounted) setState(() => tuyaPtz = ptz);
            },
          ),
        ],
        if (d.local != null) ...[
          const SectionLabel('Info'),
          ListTile(
            dense: true,
            title: const Text('Alamat'),
            trailing: Text('${d.local!.host}:${d.local!.rtspPort}'),
          ),
          ListTile(
            dense: true,
            title: const Text('ONVIF'),
            trailing: Text(d.local!.useOnvif
                ? (onvifPtz ? 'Aktif · PTZ' : 'Aktif')
                : 'Nonaktif'),
          ),
        ],
        const SizedBox(height: 32),
      ]),
    );
  }
}
