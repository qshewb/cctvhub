import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'gallery_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final cs = Theme.of(context).colorScheme;

    Widget themeOption(ThemeMode m, IconData icon, String label) {
      final sel = s.themeMode == m;
      return Expanded(
        child: GestureDetector(
          onTap: () => s.setTheme(m),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: sel ? cs.primary.withValues(alpha: 0.12) : cs.surfaceContainerLow,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: sel ? cs.primary : cs.outlineVariant, width: sel ? 1.5 : 1),
            ),
            child: Column(children: [
              Icon(icon, color: sel ? cs.primary : cs.onSurfaceVariant),
              const SizedBox(height: 6),
              Text(label,
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      color: sel ? cs.primary : cs.onSurface)),
            ]),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Setelan')),
      body: ListView(children: [
        const SectionLabel('Tampilan'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            themeOption(ThemeMode.light, Icons.light_mode_rounded, 'Terang'),
            const SizedBox(width: 10),
            themeOption(ThemeMode.dark, Icons.dark_mode_rounded, 'Gelap'),
            const SizedBox(width: 10),
            themeOption(ThemeMode.system, Icons.brightness_auto_rounded, 'Otomatis'),
          ]),
        ),
        const SectionLabel('Warna aksen'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            for (var i = 0; i < accentColors.length; i++)
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: GestureDetector(
                  onTap: () => s.setAccent(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: accentColors[i],
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: s.accent == i ? cs.onSurface : Colors.transparent, width: 3),
                    ),
                    child: s.accent == i
                        ? const Icon(Icons.check_rounded, color: Colors.white, size: 20)
                        : null,
                  ),
                ),
              ),
          ]),
        ),
        const SectionLabel('Kamera'),
        SwitchListTile(
          title: const Text('Preview langsung di grid'),
          subtitle: const Text('Matikan untuk menghemat kuota & baterai'),
          value: s.livePreview,
          onChanged: s.setLivePreview,
        ),
        ListTile(
          title: const Text('Kolom grid kamera'),
          trailing: SegmentedButton<int>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 1, label: Text('1')),
              ButtonSegment(value: 2, label: Text('2')),
              ButtonSegment(value: 3, label: Text('3')),
            ],
            selected: {s.gridColumns},
            onSelectionChanged: (v) => s.setColumns(v.first),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.photo_library_outlined),
          title: const Text('Galeri snapshot & rekaman'),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () =>
              Navigator.push(context, MaterialPageRoute(builder: (_) => const GalleryScreen())),
        ),
        const SectionLabel('Tentang'),
        ListTile(
          leading: const Icon(Icons.shield_outlined),
          title: const Text('Keamanan data'),
          subtitle: const Text(
              'Kredensial disimpan terenkripsi di perangkat ini dan hanya dikirim ke kamera/cloud terkait.'),
        ),
        const ListTile(
          leading: Icon(Icons.info_outline_rounded),
          title: Text('CCTV Hub'),
          subtitle: Text('Versi 1.0.0'),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
