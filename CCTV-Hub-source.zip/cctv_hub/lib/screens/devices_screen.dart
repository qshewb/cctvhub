import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../store.dart';
import '../widgets/common.dart';
import '../widgets/device_controls.dart';
import 'add_account_screen.dart';

const _powerCodes = ['switch_led', 'switch', 'switch_1', 'switch_on'];

class DevicesScreen extends StatelessWidget {
  const DevicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final list = s.smartDevices;

    return Scaffold(
      appBar: AppBar(title: const Text('Perangkat Pintar')),
      body: RefreshIndicator(
        onRefresh: s.refresh,
        child: list.isEmpty
            ? ListView(children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7,
                  child: EmptyState(
                    icon: Icons.lightbulb_rounded,
                    title: 'Belum ada perangkat',
                    message:
                        'Lampu, stopkontak, sensor, dan perangkat Bardi/Smart Life lain muncul di sini setelah akun Tuya ditambahkan.',
                    action: 'Tambah akun',
                    onAction: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => const AddAccountScreen())),
                  ),
                ),
              ])
            : GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.15,
                ),
                itemCount: list.length,
                itemBuilder: (_, i) => _DeviceCard(device: list[i]),
              ),
      ),
    );
  }
}

class _DeviceCard extends StatefulWidget {
  final Device device;
  const _DeviceCard({required this.device});
  @override
  State<_DeviceCard> createState() => _DeviceCardState();
}

class _DeviceCardState extends State<_DeviceCard> {
  String? powerCode;
  bool on = false;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    final st = {
      for (final e in (widget.device.raw['status'] as List? ?? []))
        e['code'].toString(): e['value']
    };
    for (final c in _powerCodes) {
      if (st[c] is bool) {
        powerCode = c;
        on = st[c];
        break;
      }
    }
  }

  Future<void> _toggle() async {
    if (powerCode == null || busy || !widget.device.online) return;
    setState(() {
      busy = true;
      on = !on;
    });
    try {
      await context
          .read<AppStore>()
          .tuya(widget.device.accountId)
          .command(widget.device.id, powerCode!, on);
    } catch (e) {
      if (mounted) {
        setState(() => on = !on);
        toast(context, e.toString());
      }
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final d = widget.device;
    final active = on && d.online;
    return Material(
      color: active ? cs.primary.withValues(alpha: 0.12) : cs.surfaceContainerLow,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: active ? cs.primary.withValues(alpha: 0.4) : cs.outlineVariant),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => DeviceDetailScreen(device: d))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: cs.surfaceContainer,
                  borderRadius: BorderRadius.circular(14),
                ),
                clipBehavior: Clip.antiAlias,
                child: d.icon != null
                    ? Image.network(d.icon!,
                        errorBuilder: (_, __, ___) => Icon(Icons.devices_other_rounded, color: cs.primary))
                    : Icon(Icons.devices_other_rounded, color: cs.primary),
              ),
              const Spacer(),
              if (powerCode != null)
                GestureDetector(
                  onTap: _toggle,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: active ? cs.primary : cs.surfaceContainer,
                    ),
                    child: Icon(Icons.power_settings_new_rounded,
                        size: 20, color: active ? cs.onPrimary : cs.onSurfaceVariant),
                  ),
                ),
            ]),
            const Spacer(),
            Text(d.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 4),
            Row(children: [
              StatusDot(d.online),
              const SizedBox(width: 6),
              Text(
                  !d.online
                      ? 'Offline'
                      : powerCode == null
                          ? 'Online'
                          : (on ? 'Menyala' : 'Mati'),
                  style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            ]),
          ]),
        ),
      ),
    );
  }
}

class DeviceDetailScreen extends StatefulWidget {
  final Device device;
  const DeviceDetailScreen({super.key, required this.device});
  @override
  State<DeviceDetailScreen> createState() => _DeviceDetailScreenState();
}

class _DeviceDetailScreenState extends State<DeviceDetailScreen> {
  final key = GlobalKey<DeviceControlsState>();
  Device get device => widget.device;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final fav = s.favorites.contains(device.id);
    return Scaffold(
      appBar: AppBar(
        title: Text(device.name),
        actions: [
          IconButton(
            icon: Icon(fav ? Icons.star_rounded : Icons.star_outline_rounded,
                color: fav ? const Color(0xFFFBBF24) : null),
            onPressed: () => s.toggleFavorite(device.id),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => key.currentState?.load(),
          ),
        ],
      ),
      body: ListView(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Row(children: [
            StatusDot(device.online),
            const SizedBox(width: 8),
            Text(device.online ? 'Online' : 'Offline',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ]),
        ),
        const SizedBox(height: 8),
        DeviceControls(key: key, device: device),
        const SizedBox(height: 32),
      ]),
    );
  }
}
