import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../brands.dart';
import '../models.dart';
import '../services/tuya.dart';
import '../store.dart';
import '../widgets/common.dart';
import 'add_camera_screen.dart';

/// Langkah 1: pilih merek. Langkah 2: isi detail akun.
class AddAccountScreen extends StatelessWidget {
  final Account? existing;
  const AddAccountScreen({super.key, this.existing});

  @override
  Widget build(BuildContext context) {
    if (existing != null) return _AccountForm(brand: brandById(existing!.brandId), existing: existing);
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Pilih merek')),
      body: GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.35),
        itemCount: brands.length,
        itemBuilder: (_, i) {
          final b = brands[i];
          return Material(
            color: cs.surfaceContainerLow,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.outlineVariant)),
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (_) => _AccountForm(brand: b))),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  BrandBadge(b, size: 40),
                  const Spacer(),
                  Text(b.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(
                    b.methods.map((m) => m == ConnType.tuya ? 'Cloud' : 'Lokal').join(' / '),
                    style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
                  ),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _AccountForm extends StatefulWidget {
  final Brand brand;
  final Account? existing;
  const _AccountForm({required this.brand, this.existing});

  @override
  State<_AccountForm> createState() => _AccountFormState();
}

class _AccountFormState extends State<_AccountForm> {
  late ConnType type = widget.existing?.type ?? widget.brand.methods.first;
  late final name = TextEditingController(text: widget.existing?.name ?? 'Akun ${widget.brand.name}');
  late final id = TextEditingController(text: widget.existing?.clientId ?? '');
  late final secret = TextEditingController(text: widget.existing?.clientSecret ?? '');
  late String region = widget.existing?.region ?? 'sg';
  bool hide = true;
  bool saving = false;

  Future<void> _save() async {
    if (name.text.trim().isEmpty) return toast(context, 'Nama akun wajib diisi');
    final a = Account(
      id: widget.existing?.id ?? newId(),
      brandId: widget.brand.id,
      name: name.text.trim(),
      type: type,
      region: region,
      clientId: id.text.trim(),
      clientSecret: secret.text.trim(),
      cameras: widget.existing?.cameras,
    );
    setState(() => saving = true);
    if (type == ConnType.tuya) {
      if (a.clientId.isEmpty || a.clientSecret.isEmpty) {
        setState(() => saving = false);
        return toast(context, 'Isi Access ID dan Access Secret');
      }
      try {
        await TuyaClient(a).test();
      } catch (e) {
        setState(() => saving = false);
        if (mounted) toast(context, 'Gagal terhubung: $e');
        return;
      }
    }
    final store = context.read<AppStore>();
    await store.upsertAccount(a);
    if (!mounted) return;
    if (type == ConnType.local && widget.existing == null) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => AddCameraScreen(accountId: a.id)));
    } else {
      Navigator.pop(context);
      toast(context, 'Akun tersimpan');
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.brand;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'Tambah ${b.name}' : 'Ubah akun')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          BrandBadge(b, size: 52),
          const SizedBox(width: 14),
          Expanded(child: Text(b.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
        ]),
        if (b.hint.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: cs.primary.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14)),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.info_outline_rounded, size: 18, color: cs.primary),
              const SizedBox(width: 10),
              Expanded(child: Text(b.hint, style: const TextStyle(height: 1.4, fontSize: 13))),
            ]),
          ),
        ],
        if (b.methods.length > 1) ...[
          const SizedBox(height: 18),
          SegmentedButton<ConnType>(
            segments: const [
              ButtonSegment(value: ConnType.tuya, label: Text('Cloud (Tuya)'), icon: Icon(Icons.cloud_outlined)),
              ButtonSegment(value: ConnType.local, label: Text('Lokal'), icon: Icon(Icons.wifi_rounded)),
            ],
            selected: {type},
            onSelectionChanged: (v) => setState(() => type = v.first),
          ),
        ],
        const SizedBox(height: 18),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama akun (mis. Rumah)')),
        if (type == ConnType.tuya) ...[
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: region,
            decoration: const InputDecoration(labelText: 'Pusat data'),
            items: tuyaRegions.entries
                .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                .toList(),
            onChanged: (v) => setState(() => region = v ?? 'sg'),
          ),
          const SizedBox(height: 12),
          TextField(controller: id, decoration: const InputDecoration(labelText: 'Access ID / Client ID')),
          const SizedBox(height: 12),
          TextField(
            controller: secret,
            obscureText: hide,
            decoration: InputDecoration(
              labelText: 'Access Secret',
              suffixIcon: IconButton(
                icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                onPressed: () => setState(() => hide = !hide),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('Cara mendapatkan Access ID & Secret',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              childrenPadding: const EdgeInsets.only(bottom: 8),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _Step(1, 'Buka iot.tuya.com dan daftar akun developer (gratis).'),
                _Step(2, 'Cloud → Development → Create Cloud Project. Pilih "Smart Home" dan pusat data yang sama dengan akun aplikasi Anda.'),
                _Step(3, 'Di tab Service API, pastikan aktif: IoT Core, Authorization Token Management, dan IoT Video Live Stream (untuk kamera).'),
                _Step(4, 'Tab Devices → Link App Account → scan QR pakai aplikasi Smart Life / Tuya. Perangkat Bardi bisa ditambahkan dulu ke Smart Life.'),
                _Step(5, 'Salin Access ID dan Access Secret dari tab Overview ke sini.'),
              ],
            ),
          ),
        ] else ...[
          const SizedBox(height: 12),
          Text('Setelah disimpan, Anda bisa menambahkan satu atau beberapa kamera ke akun ini.',
              style: TextStyle(color: cs.onSurfaceVariant)),
        ],
        const SizedBox(height: 24),
        FilledButton(
          onPressed: saving ? null : _save,
          child: saving
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(type == ConnType.tuya ? 'Hubungkan' : 'Lanjut'),
        ),
      ]),
    );
  }
}

class _Step extends StatelessWidget {
  final int n;
  final String text;
  const _Step(this.n, this.text);
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        CircleAvatar(
          radius: 11,
          backgroundColor: cs.primary,
          child: Text('$n', style: TextStyle(fontSize: 11, color: cs.onPrimary, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: const TextStyle(height: 1.4, fontSize: 13))),
      ]),
    );
  }
}
