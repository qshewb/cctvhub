import 'dart:io';

import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

import '../services/media_store.dart';
import '../widgets/common.dart';

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});
  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<File> files = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    files = await MediaStore.list();
    if (mounted) setState(() => loading = false);
  }

  String _title(File f) {
    final n = f.uri.pathSegments.last;
    return n.substring(0, n.lastIndexOf('.')).replaceAll('_', ' ');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Galeri')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : files.isEmpty
              ? const EmptyState(
                  icon: Icons.photo_library_rounded,
                  title: 'Galeri kosong',
                  message: 'Snapshot dan rekaman dari layar kamera akan tersimpan di sini.')
              : GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 4 / 3),
                  itemCount: files.length,
                  itemBuilder: (_, i) {
                    final f = files[i];
                    final video = f.path.endsWith('.mkv');
                    return GestureDetector(
                      onTap: () async {
                        await Navigator.push(
                            context, MaterialPageRoute(builder: (_) => _Viewer(file: f, title: _title(f))));
                        _load();
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Stack(fit: StackFit.expand, children: [
                          video
                              ? Container(
                                  color: Theme.of(context).colorScheme.surfaceContainerHigh,
                                  child: const Icon(Icons.movie_rounded, size: 36))
                              : Image.file(f, fit: BoxFit.cover, cacheWidth: 400),
                          if (video)
                            const Positioned(
                                right: 8,
                                top: 8,
                                child: Icon(Icons.play_circle_fill_rounded, color: Colors.white)),
                          Positioned(
                            left: 0,
                            right: 0,
                            bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.fromLTRB(8, 14, 8, 6),
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                    colors: [Color(0xAA000000), Color(0x00000000)]),
                              ),
                              child: Text(_title(f),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontSize: 11)),
                            ),
                          ),
                        ]),
                      ),
                    );
                  },
                ),
    );
  }
}

class _Viewer extends StatefulWidget {
  final File file;
  final String title;
  const _Viewer({required this.file, required this.title});
  @override
  State<_Viewer> createState() => _ViewerState();
}

class _ViewerState extends State<_Viewer> {
  Player? player;
  VideoController? ctrl;

  @override
  void initState() {
    super.initState();
    if (widget.file.path.endsWith('.mkv')) {
      player = Player();
      ctrl = VideoController(player!);
      player!.open(Media(widget.file.path));
    }
  }

  @override
  void dispose() {
    player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, style: const TextStyle(color: Colors.white, fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () async {
              await widget.file.delete();
              if (mounted) Navigator.pop(context);
            },
          ),
        ],
      ),
      body: Center(
        child: ctrl != null
            ? Video(controller: ctrl!)
            : InteractiveViewer(maxScale: 5, child: Image.file(widget.file)),
      ),
    );
  }
}
