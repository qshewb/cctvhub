import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../brands.dart';
import '../models.dart';
import '../store.dart';
import '../widgets/common.dart';
import 'add_account_screen.dart';
import 'add_camera_screen.dart';

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Akun')),
      floatingActionButton: s.accounts.isEmpty
          ? null
          : FloatingActionButton.extended(
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const AddAccountScreen())),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Tambah akun'),
            ),
      body: s.accounts.isEmpty
          ? EmptyState(
              icon: Icons.link_rounded,
              title: 'Hubungkan akun pertama',
              message: 'Gabungkan Bardi, Smart Life, Yoosee, V380, Eyesec dan merek lain dalam satu aplikasi.',
              action: 'Tambah akun',
              onAction: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const AddAccountScreen())),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
              itemCount: s.accounts.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final a = s.accounts[i];
                final b = brandById(a.brandId);
                final count = s.devices.where((d) => d.accountId == a.id).length;
                final err = s.errors[a.id];
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    leading: BrandBadge(b),
                    title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(
                      err ??
                          '${b.name} · ${a.type == ConnType.tuya ? 'Cloud' : 'Lokal'} · $count perangkat',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: err != null ? Theme.of(context).colorScheme.error : null),
                    ),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => AccountDetailScreen(accountId: a.id))),
                  ),
                );
              },
            ),
    );
  }
}

class AccountDetailScreen extends StatelessWidget {
  final String accountId;
  const AccountDetailScreen({super.key, required this.accountId});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppStore>();
    final a = s.account(accountId);
    if (a == null) return const Scaffold();
    final b = brandById(a.brandId);
    final devs = s.devices.where((d) => d.accountId == a.id).toList();

    return Scaffold(
      appBar: AppBar(title: Text(a.name), actions: [
        IconButton(
          icon: const Icon(Icons.edit_outlined),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => AddAccountScreen(existing: a))),
        ),
        IconButton(
          icon: const Icon(Icons.delete_outline_rounded),
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (c) => AlertDialog(
                title: const Text('Hapus akun?'),
                content: Text('${a.name} dan semua perangkatnya akan dihapus dari aplikasi ini.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
                  FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Hapus')),
                ],
              ),
            );
            if (ok == true && context.mounted) {
              Navigator.pop(context);
              s.removeAccount(a.id);
            }
          },
        ),
      ]),
      floatingActionButton: a.type == ConnType.local
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => AddCameraScreen(accountId: a.id))),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Tambah kamera'),
            )
          : null,
      body: RefreshIndicator(
        onRefresh: s.refresh,
        child: ListView(padding: const EdgeInsets.only(bottom: 100), children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
            child: Row(children: [
              BrandBadge(b, size: 52),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(b.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  Text(
                      a.type == ConnType.tuya
                          ? 'Tuya Cloud · ${tuyaRegions[a.region] ?? a.region}'
                          : 'Koneksi lokal (RTSP/ONVIF)',
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                ]),
              ),
            ]),
          ),
          if (s.errors[a.id] != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Card(
                color: Theme.of(context).colorScheme.errorContainer,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(s.errors[a.id]!,
                      style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer)),
                ),
              ),
            ),
          SectionLabel('Perangkat (${devs.length})'),
          if (devs.isEmpty)
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                  a.type == ConnType.local
                      ? 'Belum ada kamera. Ketuk "Tambah kamera".'
                      : 'Tidak ada perangkat. Pastikan akun aplikasi sudah ditautkan ke proyek Tuya.',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          for (final d in devs)
            ListTile(
              leading: Icon(d.isCamera ? Icons.videocam_rounded : Icons.devices_other_rounded),
              title: Text(d.name),
              subtitle: Text(d.local != null ? d.local!.host : (d.online ? 'Online' : 'Offline')),
              trailing: d.local != null
                  ? IconButton(
                      icon: const Icon(Icons.delete_outline_rounded),
                      onPressed: () => s.removeCamera(a.id, d.id),
                    )
                  : StatusDot(d.online),
              onTap: d.local == null
                  ? null
                  : () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => AddCameraScreen(accountId: a.id, existing: d.local))),
            ),
        ]),
      ),
    );
  }
}
