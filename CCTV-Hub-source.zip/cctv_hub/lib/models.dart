import 'dart:convert';

/// Cara aplikasi terhubung ke sebuah akun/merek.
enum ConnType { tuya, local }

class Account {
  final String id;
  String brandId;
  String name;
  ConnType type;

  // Tuya Cloud
  String region;
  String clientId;
  String clientSecret;

  // Kamera lokal (RTSP / ONVIF) milik akun ini
  List<LocalCamera> cameras;

  Account({
    required this.id,
    required this.brandId,
    required this.name,
    required this.type,
    this.region = 'sg',
    this.clientId = '',
    this.clientSecret = '',
    List<LocalCamera>? cameras,
  }) : cameras = cameras ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'brandId': brandId,
        'name': name,
        'type': type.name,
        'region': region,
        'clientId': clientId,
        'clientSecret': clientSecret,
        'cameras': cameras.map((c) => c.toJson()).toList(),
      };

  factory Account.fromJson(Map<String, dynamic> j) => Account(
        id: j['id'],
        brandId: j['brandId'],
        name: j['name'],
        type: ConnType.values.byName(j['type']),
        region: j['region'] ?? 'sg',
        clientId: j['clientId'] ?? '',
        clientSecret: j['clientSecret'] ?? '',
        cameras: ((j['cameras'] ?? []) as List)
            .map((e) => LocalCamera.fromJson(e))
            .toList(),
      );
}

class LocalCamera {
  final String id;
  String name;
  String host;
  int rtspPort;
  int onvifPort;
  String username;
  String password;
  String mainPath; // contoh: /onvif1, /live/ch00_0
  String subPath;
  bool useOnvif;
  String? onvifStreamUri; // hasil deteksi ONVIF (cache)

  LocalCamera({
    required this.id,
    required this.name,
    required this.host,
    this.rtspPort = 554,
    this.onvifPort = 80,
    this.username = 'admin',
    this.password = '',
    this.mainPath = '/',
    this.subPath = '',
    this.useOnvif = true,
    this.onvifStreamUri,
  });

  String rtspUrl({bool sub = false}) {
    final path = (sub && subPath.isNotEmpty) ? subPath : mainPath;
    final p = path.startsWith('/') ? path : '/$path';
    final auth = username.isEmpty
        ? ''
        : '${Uri.encodeComponent(username)}:${Uri.encodeComponent(password)}@';
    return 'rtsp://$auth$host:$rtspPort$p';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'host': host,
        'rtspPort': rtspPort,
        'onvifPort': onvifPort,
        'username': username,
        'password': password,
        'mainPath': mainPath,
        'subPath': subPath,
        'useOnvif': useOnvif,
        'onvifStreamUri': onvifStreamUri,
      };

  factory LocalCamera.fromJson(Map<String, dynamic> j) => LocalCamera(
        id: j['id'],
        name: j['name'],
        host: j['host'],
        rtspPort: j['rtspPort'] ?? 554,
        onvifPort: j['onvifPort'] ?? 80,
        username: j['username'] ?? '',
        password: j['password'] ?? '',
        mainPath: j['mainPath'] ?? '/',
        subPath: j['subPath'] ?? '',
        useOnvif: j['useOnvif'] ?? true,
        onvifStreamUri: j['onvifStreamUri'],
      );
}

/// Perangkat yang tampil di aplikasi (gabungan dari semua akun).
class Device {
  final String id;
  final String accountId;
  final String name;
  final String category; // 'sp' = kamera Tuya
  final bool online;
  final String? icon;
  final LocalCamera? local;
  final Map<String, dynamic> raw;

  Device({
    required this.id,
    required this.accountId,
    required this.name,
    required this.category,
    required this.online,
    this.icon,
    this.local,
    this.raw = const {},
  });

  bool get isCamera => local != null || category == 'sp' || category == 'dghsxj';
  bool get isTuya => local == null;
}

/// Satu fungsi (fitur) perangkat Tuya, dibaca dari spesifikasi perangkat.
class DeviceFunction {
  final String code;
  final String name;
  final String type; // Boolean, Enum, Integer, String, Json
  final Map<String, dynamic> values;

  DeviceFunction(this.code, this.name, this.type, this.values);

  factory DeviceFunction.fromJson(Map<String, dynamic> j) {
    Map<String, dynamic> v = {};
    try {
      final raw = j['values'];
      v = raw is String ? (raw.isEmpty ? {} : jsonDecode(raw)) : (raw ?? {});
    } catch (_) {}
    return DeviceFunction(
      j['code'] ?? '',
      (j['name'] ?? j['code'] ?? '').toString(),
      (j['type'] ?? '').toString(),
      v,
    );
  }
}

String newId() =>
    DateTime.now().microsecondsSinceEpoch.toRadixString(36) +
    (DateTime.now().hashCode & 0xffff).toRadixString(36);
