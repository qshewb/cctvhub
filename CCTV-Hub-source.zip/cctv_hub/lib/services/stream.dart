import 'package:media_kit/media_kit.dart';
import '../models.dart';
import '../store.dart';
import 'onvif.dart';

/// Menentukan URL stream untuk kamera mana pun (Tuya atau lokal).
Future<String> resolveStream(AppStore store, Device d, {bool sub = false}) async {
  final c = d.local;
  if (c == null) {
    return store.tuya(d.accountId).streamUrl(d.id);
  }
  // Jalur stream manual diutamakan bila sudah diisi.
  final manual = c.mainPath.trim();
  if (manual.isNotEmpty && manual != '/') return c.rtspUrl(sub: sub);
  if (c.useOnvif) {
    if (c.onvifStreamUri != null && !sub) return c.onvifStreamUri!;
    try {
      final uri = await OnvifClient(c).streamUri();
      if (uri != null) {
        c.onvifStreamUri = uri;
        store.persist();
        return uri;
      }
    } catch (_) {}
  }
  return c.rtspUrl(sub: sub);
}

/// Opsi mpv untuk RTSP: transport TCP (lebih stabil) dan latensi rendah.
Future<void> tunePlayer(Player p) async {
  final dynamic n = p.platform;
  if (p.platform is NativePlayer) {
    try {
      await n.setProperty('demuxer-lavf-o', 'rtsp_transport=tcp');
      await n.setProperty('profile', 'low-latency');
      await n.setProperty('untimed', 'yes');
      await n.setProperty('network-timeout', '15');
    } catch (_) {}
  }
}
