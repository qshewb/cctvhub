import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

import '../models.dart';

class TuyaException implements Exception {
  final String message;
  TuyaException(this.message);
  @override
  String toString() => message;
}

/// Klien Tuya OpenAPI (Cloud) dengan tanda tangan HMAC-SHA256.
class TuyaClient {
  static const _hosts = {
    'cn': 'https://openapi.tuyacn.com',
    'us': 'https://openapi.tuyaus.com',
    'ue': 'https://openapi-ueaz.tuyaus.com',
    'eu': 'https://openapi.tuyaeu.com',
    'we': 'https://openapi-weaz.tuyaeu.com',
    'in': 'https://openapi.tuyain.com',
    'sg': 'https://openapi-sg.iotbing.com',
  };

  final String clientId;
  final String secret;
  final String host;

  String? _token;
  DateTime _expiry = DateTime.fromMillisecondsSinceEpoch(0);

  TuyaClient(Account a)
      : clientId = a.clientId.trim(),
        secret = a.clientSecret.trim(),
        host = _hosts[a.region] ?? _hosts['us']!;

  String _sha256(String s) => sha256.convert(utf8.encode(s)).toString();
  String _hmac(String s) =>
      Hmac(sha256, utf8.encode(secret)).convert(utf8.encode(s)).toString().toUpperCase();
  String _nonce() =>
      List.generate(16, (_) => Random.secure().nextInt(16).toRadixString(16)).join();

  String _sortedPath(String path) {
    final uri = Uri.parse(path);
    if (uri.queryParameters.isEmpty) return uri.path;
    final keys = uri.queryParameters.keys.toList()..sort();
    return '${uri.path}?${keys.map((k) => '$k=${uri.queryParameters[k]}').join('&')}';
  }

  Future<Map<String, dynamic>> _send(String method, String path,
      {Object? body, bool auth = true}) async {
    if (auth) await _ensureToken();
    final t = DateTime.now().millisecondsSinceEpoch.toString();
    final nonce = _nonce();
    final bodyStr = body == null ? '' : jsonEncode(body);
    final stringToSign = '$method\n${_sha256(bodyStr)}\n\n${_sortedPath(path)}';
    final signStr = auth
        ? '$clientId$_token$t$nonce$stringToSign'
        : '$clientId$t$nonce$stringToSign';
    final headers = {
      'client_id': clientId,
      'sign': _hmac(signStr),
      't': t,
      'nonce': nonce,
      'sign_method': 'HMAC-SHA256',
      'Content-Type': 'application/json',
      if (auth) 'access_token': _token!,
    };
    final uri = Uri.parse('$host$path');
    final res = method == 'GET'
        ? await http.get(uri, headers: headers).timeout(const Duration(seconds: 15))
        : await http
            .post(uri, headers: headers, body: bodyStr)
            .timeout(const Duration(seconds: 15));
    final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    if (j['success'] != true) {
      throw TuyaException(_explain(j['code'], j['msg']?.toString()));
    }
    return j;
  }

  String _explain(dynamic code, String? msg) {
    switch (code) {
      case 1004:
        return 'Access Secret salah (sign invalid).';
      case 1005:
      case 2009:
        return 'Access ID salah atau tidak dikenal.';
      case 1106:
        return 'Akses ditolak. Pastikan akun aplikasi sudah ditautkan ke proyek cloud.';
      case 28841105:
      case 28841002:
        return 'Layanan API belum diaktifkan di proyek Tuya (mis. IoT Video Live Stream).';
      default:
        return 'Tuya: ${msg ?? 'kesalahan'} (kode $code)';
    }
  }

  Future<void> _ensureToken() async {
    if (_token != null && DateTime.now().isBefore(_expiry)) return;
    final j = await _send('GET', '/v1.0/token?grant_type=1', auth: false);
    _token = j['result']['access_token'];
    final exp = (j['result']['expire_time'] ?? 3600) as int;
    _expiry = DateTime.now().add(Duration(seconds: exp - 60));
  }

  /// Uji koneksi; melempar TuyaException bila gagal.
  Future<void> test() async {
    _token = null;
    await _ensureToken();
  }

  Future<List<Device>> devices(String accountId) async {
    final out = <Device>[];
    String? lastRow;
    for (var page = 0; page < 20; page++) {
      final q = lastRow == null ? '' : '&last_row_key=$lastRow';
      final j = await _send('GET', '/v1.0/iot-01/associated-users/devices?size=100$q');
      final r = j['result'] as Map<String, dynamic>;
      for (final d in (r['devices'] as List? ?? [])) {
        final icon = d['icon']?.toString();
        out.add(Device(
          id: d['id'],
          accountId: accountId,
          name: d['name'] ?? 'Perangkat',
          category: d['category'] ?? '',
          online: d['online'] == true,
          icon: icon == null || icon.isEmpty
              ? null
              : (icon.startsWith('http') ? icon : 'https://images.tuyaus.com/$icon'),
          raw: Map<String, dynamic>.from(d),
        ));
      }
      if (r['has_more'] != true) break;
      lastRow = r['last_row_key']?.toString();
      if (lastRow == null) break;
    }
    return out;
  }

  Future<List<DeviceFunction>> functions(String deviceId) async {
    final j = await _send('GET', '/v1.0/iot-03/devices/$deviceId/functions');
    final list = (j['result']?['functions'] as List?) ?? [];
    return list.map((e) => DeviceFunction.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<Map<String, dynamic>> status(String deviceId) async {
    final j = await _send('GET', '/v1.0/iot-03/devices/$deviceId/status');
    final m = <String, dynamic>{};
    for (final s in (j['result'] as List? ?? [])) {
      m[s['code']] = s['value'];
    }
    return m;
  }

  Future<void> command(String deviceId, String code, dynamic value) async {
    await _send('POST', '/v1.0/iot-03/devices/$deviceId/commands', body: {
      'commands': [
        {'code': code, 'value': value}
      ]
    });
  }

  /// Minta URL live stream kamera (RTSP, cadangan HLS).
  Future<String> streamUrl(String deviceId) async {
    for (final type in ['rtsp', 'hls']) {
      try {
        final j = await _send('POST', '/v1.0/devices/$deviceId/stream/actions/allocate',
            body: {'type': type});
        final url = j['result']?['url']?.toString();
        if (url != null && url.isNotEmpty) return url;
      } on TuyaException {
        if (type == 'hls') rethrow;
      }
    }
    throw TuyaException('Stream kamera tidak tersedia.');
  }
}
