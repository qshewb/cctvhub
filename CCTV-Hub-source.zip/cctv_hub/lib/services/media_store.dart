import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';

/// Penyimpanan snapshot & rekaman di folder aplikasi.
class MediaStore {
  static Future<Directory> dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/CCTVHub');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static String _safe(String s) => s.replaceAll(RegExp(r'[^\w\-]+'), '_');

  static String _stamp() {
    final n = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    return '${n.year}${two(n.month)}${two(n.day)}_${two(n.hour)}${two(n.minute)}${two(n.second)}';
  }

  static Future<File> saveSnapshot(String camName, Uint8List bytes) async {
    final d = await dir();
    final f = File('${d.path}/${_safe(camName)}_${_stamp()}.jpg');
    return f.writeAsBytes(bytes);
  }

  static Future<String> newRecordingPath(String camName) async {
    final d = await dir();
    return '${d.path}/${_safe(camName)}_${_stamp()}.mkv';
  }

  static Future<List<File>> list() async {
    final d = await dir();
    final files = d
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.jpg') || f.path.endsWith('.mkv'))
        .toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    return files;
  }
}
