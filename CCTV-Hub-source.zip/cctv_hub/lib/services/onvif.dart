import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

import '../models.dart';

/// Klien ONVIF ringan: deteksi stream, PTZ, dan preset.
class OnvifClient {
  final LocalCamera cam;
  String? _mediaUrl;
  String? _ptzUrl;
  String? _profile;
  Duration _clockOffset = Duration.zero;

  OnvifClient(this.cam);

  String get _deviceUrl => 'http://${cam.host}:${cam.onvifPort}/onvif/device_service';

  String _security() {
    if (cam.username.isEmpty) return '';
    final nonce = List<int>.generate(16, (_) => Random.secure().nextInt(256));
    final created = DateTime.now().toUtc().add(_clockOffset).toIso8601String().split('.').first + 'Z';
    final digest = base64.encode(sha1
        .convert([...nonce, ...utf8.encode(created), ...utf8.encode(cam.password)]).bytes);
    return '''<s:Header><Security s:mustUnderstand="1" xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"><UsernameToken><Username>${_esc(cam.username)}</Username><Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">$digest</Password><Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">${base64.encode(nonce)}</Nonce><Created xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">$created</Created></UsernameToken></Security></s:Header>''';
  }

  String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  Future<String> _call(String url, String body, {bool secure = true}) async {
    final env =
        '<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">${secure ? _security() : ''}<s:Body xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">$body</s:Body></s:Envelope>';
    final res = await http
        .post(Uri.parse(url),
            headers: {'Content-Type': 'application/soap+xml; charset=utf-8'}, body: env)
        .timeout(const Duration(seconds: 8));
    final text = utf8.decode(res.bodyBytes, allowMalformed: true);
    if (res.statusCode >= 400) {
      if (text.contains('NotAuthorized') || res.statusCode == 401) {
        throw Exception('ONVIF: username/password salah');
      }
      throw Exception('ONVIF error ${res.statusCode}');
    }
    return text;
  }

  String? _tag(String xml, String tag) {
    final m = RegExp('<(?:[\\w-]+:)?$tag[^>]*>(.*?)</(?:[\\w-]+:)?$tag>', dotAll: true)
        .firstMatch(xml);
    return m?.group(1)?.trim();
  }

  Future<void> _syncClock() async {
    try {
      final x = await _call(_deviceUrl,
          '<GetSystemDateAndTime xmlns="http://www.onvif.org/ver10/device/wsdl"/>',
          secure: false);
      final utc = _tag(x, 'UTCDateTime');
      if (utc == null) return;
      int g(String t) => int.tryParse(_tag(utc, t) ?? '') ?? 0;
      final cam = DateTime.utc(g('Year'), g('Month'), g('Day'), g('Hour'), g('Minute'), g('Second'));
      if (cam.year > 2000) _clockOffset = cam.difference(DateTime.now().toUtc());
    } catch (_) {}
  }

  Future<void> _init() async {
    if (_mediaUrl != null) return;
    await _syncClock();
    final caps = await _call(_deviceUrl,
        '<GetCapabilities xmlns="http://www.onvif.org/ver10/device/wsdl"><Category>All</Category></GetCapabilities>');
    final media = _tag(caps, 'Media');
    final ptz = _tag(caps, 'PTZ');
    _mediaUrl = (media != null ? _tag(media, 'XAddr') : null) ?? _deviceUrl;
    _ptzUrl = ptz != null ? _tag(ptz, 'XAddr') : null;
    final profiles = await _call(_mediaUrl!,
        '<GetProfiles xmlns="http://www.onvif.org/ver10/media/wsdl"/>');
    _profile = RegExp(r'<(?:[\w-]+:)?Profiles[^>]*token="([^"]+)"').firstMatch(profiles)?.group(1);
  }

  bool get hasPtz => _ptzUrl != null;

  /// Kembalikan URL RTSP (dengan kredensial) dari ONVIF.
  Future<String?> streamUri() async {
    await _init();
    if (_profile == null) return null;
    final x = await _call(_mediaUrl!,
        '<GetStreamUri xmlns="http://www.onvif.org/ver10/media/wsdl"><StreamSetup><Stream xmlns="http://www.onvif.org/ver10/schema">RTP-Unicast</Stream><Transport xmlns="http://www.onvif.org/ver10/schema"><Protocol>RTSP</Protocol></Transport></StreamSetup><ProfileToken>$_profile</ProfileToken></GetStreamUri>');
    final uri = _tag(x, 'Uri')?.replaceAll('&amp;', '&');
    if (uri == null) return null;
    final u = Uri.parse(uri);
    // Sebagian kamera mengembalikan IP internal; pakai host yang diisi pengguna.
    return u
        .replace(
          host: cam.host,
          userInfo: cam.username.isEmpty
              ? null
              : '${Uri.encodeComponent(cam.username)}:${Uri.encodeComponent(cam.password)}',
        )
        .toString();
  }

  Future<bool> checkPtz() async {
    try {
      await _init();
      return hasPtz;
    } catch (_) {
      return false;
    }
  }

  Future<void> move(double x, double y, {double zoom = 0}) async {
    await _init();
    if (_ptzUrl == null || _profile == null) return;
    await _call(_ptzUrl!,
        '<ContinuousMove xmlns="http://www.onvif.org/ver20/ptz/wsdl"><ProfileToken>$_profile</ProfileToken><Velocity><PanTilt xmlns="http://www.onvif.org/ver10/schema" x="${x.toStringAsFixed(2)}" y="${y.toStringAsFixed(2)}"/><Zoom xmlns="http://www.onvif.org/ver10/schema" x="${zoom.toStringAsFixed(2)}"/></Velocity></ContinuousMove>');
  }

  Future<void> stop() async {
    if (_ptzUrl == null || _profile == null) return;
    await _call(_ptzUrl!,
        '<Stop xmlns="http://www.onvif.org/ver20/ptz/wsdl"><ProfileToken>$_profile</ProfileToken><PanTilt>true</PanTilt><Zoom>true</Zoom></Stop>');
  }

  Future<void> gotoPreset(int n) async {
    await _init();
    if (_ptzUrl == null || _profile == null) return;
    await _call(_ptzUrl!,
        '<GotoPreset xmlns="http://www.onvif.org/ver20/ptz/wsdl"><ProfileToken>$_profile</ProfileToken><PresetToken>$n</PresetToken></GotoPreset>');
  }

  Future<void> setPreset(int n) async {
    await _init();
    if (_ptzUrl == null || _profile == null) return;
    await _call(_ptzUrl!,
        '<SetPreset xmlns="http://www.onvif.org/ver20/ptz/wsdl"><ProfileToken>$_profile</ProfileToken><PresetToken>$n</PresetToken><PresetName>P$n</PresetName></SetPreset>');
  }
}
