import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../store.dart';
import 'common.dart';

const _labels = <String, String>{
  'switch': 'Daya',
  'switch_led': 'Lampu',
  'switch_1': 'Saklar 1',
  'switch_2': 'Saklar 2',
  'switch_3': 'Saklar 3',
  'switch_4': 'Saklar 4',
  'switch_usb1': 'USB',
  'bright_value': 'Kecerahan',
  'bright_value_v2': 'Kecerahan',
  'temp_value': 'Suhu warna',
  'temp_value_v2': 'Suhu warna',
  'work_mode': 'Mode',
  'colour_data': 'Warna',
  'colour_data_v2': 'Warna',
  'countdown_1': 'Timer (detik)',
  'basic_nightvision': 'Penglihatan malam',
  'basic_flip': 'Balik gambar',
  'basic_osd': 'Tanda waktu di video',
  'basic_indicator': 'Lampu indikator',
  'basic_private': 'Mode privasi',
  'basic_wdr': 'WDR',
  'basic_anti_flicker': 'Anti-kedip',
  'motion_switch': 'Deteksi gerakan',
  'motion_sensitivity': 'Sensitivitas gerakan',
  'motion_tracking': 'Lacak gerakan',
  'motion_area_switch': 'Area deteksi',
  'decibel_switch': 'Deteksi suara',
  'decibel_sensitivity': 'Sensitivitas suara',
  'cry_detection_switch': 'Deteksi tangis bayi',
  'humanoid_filter': 'Hanya deteksi manusia',
  'siren_switch': 'Sirene',
  'record_switch': 'Rekam ke kartu SD',
  'record_mode': 'Mode rekam',
  'sd_format': 'Format kartu SD',
  'device_restart': 'Mulai ulang',
  'floodlight_switch': 'Lampu sorot',
  'floodlight_lightness': 'Kecerahan lampu sorot',
  'child_lock': 'Kunci anak',
  'relay_status': 'Status saat listrik kembali',
  'light_mode': 'Mode indikator',
  'mode': 'Mode',
  'temp_set': 'Suhu target',
  'fan_speed_enum': 'Kecepatan kipas',
  'percent_control': 'Posisi',
  'control': 'Kontrol',
};

const _enumLabels = <String, Map<String, String>>{
  'basic_nightvision': {'0': 'Otomatis', '1': 'Mati', '2': 'Nyala'},
  'motion_sensitivity': {'0': 'Rendah', '1': 'Sedang', '2': 'Tinggi'},
  'decibel_sensitivity': {'0': 'Rendah', '1': 'Tinggi'},
  'record_mode': {'1': 'Saat ada kejadian', '2': 'Terus-menerus'},
  'work_mode': {'white': 'Putih', 'colour': 'Warna', 'scene': 'Scene', 'music': 'Musik'},
  'relay_status': {'0': 'Mati', '1': 'Nyala', '2': 'Seperti terakhir', 'off': 'Mati', 'on': 'Nyala', 'memory': 'Seperti terakhir'},
  'control': {'open': 'Buka', 'stop': 'Stop', 'close': 'Tutup'},
};

/// Kode yang ditangani di tempat lain (mis. joystick PTZ).
const hiddenCodes = {'ptz_control', 'ptz_stop', 'zoom_control', 'zoom_stop', 'ptz_calibration'};

num _n(dynamic v, num d) => v is num ? v : (num.tryParse('$v') ?? d);

String labelFor(DeviceFunction f) {
  if (_labels.containsKey(f.code)) return _labels[f.code]!;
  final n = f.name.trim();
  if (n.isNotEmpty && n != f.code) return n;
  final s = f.code.replaceAll('_', ' ');
  return s[0].toUpperCase() + s.substring(1);
}

IconData iconFor(String code) {
  if (code.contains('nightvision')) return Icons.nightlight_round;
  if (code.contains('motion')) return Icons.directions_run_rounded;
  if (code.contains('decibel') || code.contains('cry')) return Icons.graphic_eq_rounded;
  if (code.contains('siren')) return Icons.campaign_rounded;
  if (code.contains('record') || code.startsWith('sd_')) return Icons.sd_card_rounded;
  if (code.contains('flip')) return Icons.flip_rounded;
  if (code.contains('private')) return Icons.visibility_off_rounded;
  if (code.contains('indicator') || code.contains('light_mode')) return Icons.circle_outlined;
  if (code.contains('bright') || code.contains('lightness')) return Icons.brightness_6_rounded;
  if (code.contains('temp')) return Icons.thermostat_rounded;
  if (code.contains('colour')) return Icons.palette_rounded;
  if (code.contains('countdown')) return Icons.timer_outlined;
  if (code.contains('led') || code.contains('flood')) return Icons.lightbulb_rounded;
  if (code.startsWith('switch')) return Icons.power_settings_new_rounded;
  return Icons.tune_rounded;
}

/// Panel kontrol otomatis: membaca spesifikasi perangkat Tuya
/// sehingga semua fitur bawaan perangkat muncul tanpa perlu dikodekan satu per satu.
class DeviceControls extends StatefulWidget {
  final Device device;
  final void Function(List<DeviceFunction> functions)? onLoaded;
  const DeviceControls({super.key, required this.device, this.onLoaded});

  @override
  State<DeviceControls> createState() => DeviceControlsState();
}

class DeviceControlsState extends State<DeviceControls> {
  List<DeviceFunction> funcs = [];
  Map<String, dynamic> status = {};
  bool loading = true;
  String? error;
  final Set<String> busy = {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final c = context.read<AppStore>().tuya(widget.device.accountId);
      final r = await Future.wait([c.functions(widget.device.id), c.status(widget.device.id)]);
      funcs = r[0] as List<DeviceFunction>;
      status = r[1] as Map<String, dynamic>;
      widget.onLoaded?.call(funcs);
    } catch (e) {
      error = e.toString();
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> send(String code, dynamic value) async {
    final old = status[code];
    setState(() {
      status[code] = value;
      busy.add(code);
    });
    try {
      await context.read<AppStore>().tuya(widget.device.accountId).command(widget.device.id, code, value);
    } catch (e) {
      if (mounted) {
        setState(() => status[code] = old);
        toast(context, e.toString());
      }
    }
    if (mounted) setState(() => busy.remove(code));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Padding(
          padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()));
    }
    if (error != null) {
      return Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          Text(error!, textAlign: TextAlign.center),
          TextButton(onPressed: load, child: const Text('Coba lagi')),
        ]),
      );
    }
    final visible = funcs.where((f) => !hiddenCodes.contains(f.code)).toList();
    final readOnly = status.keys
        .where((k) => !funcs.any((f) => f.code == k) && !hiddenCodes.contains(k))
        .toList();
    if (visible.isEmpty && readOnly.isEmpty) {
      return const Padding(
          padding: EdgeInsets.all(24), child: Center(child: Text('Tidak ada fitur yang bisa diatur.')));
    }
    final bools = visible.where((f) => f.type == 'Boolean').toList();
    final others = visible.where((f) => f.type != 'Boolean').toList();

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (bools.isNotEmpty)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 2.3,
            children: bools.map(_toggleCard).toList(),
          ),
        ),
      for (final f in others) _control(f),
      if (readOnly.isNotEmpty) ...[
        const SectionLabel('Status'),
        for (final k in readOnly)
          ListTile(
            dense: true,
            title: Text(_labels[k] ?? k.replaceAll('_', ' ')),
            trailing: Text('${status[k]}',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ),
      ],
    ]);
  }

  Widget _toggleCard(DeviceFunction f) {
    final cs = Theme.of(context).colorScheme;
    final on = status[f.code] == true;
    final action = f.code == 'sd_format' || f.code == 'device_restart';
    return Material(
      color: on ? cs.primary : cs.surfaceContainer,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: busy.contains(f.code)
            ? null
            : () async {
                if (action) {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (c) => AlertDialog(
                      title: Text(labelFor(f)),
                      content: const Text('Yakin ingin menjalankan tindakan ini?'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
                        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ya')),
                      ],
                    ),
                  );
                  if (ok == true) send(f.code, true);
                } else {
                  send(f.code, !on);
                }
              },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(children: [
            Icon(iconFor(f.code), size: 20, color: on ? cs.onPrimary : cs.onSurfaceVariant),
            const SizedBox(width: 10),
            Expanded(
              child: Text(labelFor(f),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      color: on ? cs.onPrimary : cs.onSurface)),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _control(DeviceFunction f) {
    switch (f.type) {
      case 'Enum':
        final range = (f.values['range'] as List?)?.map((e) => e.toString()).toList() ?? [];
        final labels = _enumLabels[f.code] ?? {};
        return _block(
          f,
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: range
                .map((r) => ChoiceChip(
                      label: Text(labels[r] ?? r),
                      selected: status[f.code]?.toString() == r,
                      onSelected: (_) => send(f.code, r),
                    ))
                .toList(),
          ),
        );
      case 'Integer':
        final min = _n(f.values['min'], 0);
        final max = _n(f.values['max'], 100);
        final step = _n(f.values['step'], 1).clamp(1, 1 << 30);
        final scale = _n(f.values['scale'], 0);
        final unit = (f.values['unit'] ?? '').toString();
        final cur = _n(status[f.code], min).clamp(min, max).toDouble();
        final div = pow(10, scale);
        return _IntSlider(
          key: ValueKey(f.code),
          title: labelFor(f),
          icon: iconFor(f.code),
          min: min.toDouble(),
          max: max.toDouble(),
          divisions: max > min ? ((max - min) / step).round().clamp(1, 1000).toInt() : null,
          value: cur,
          format: (v) => '${(v / div).toStringAsFixed(scale.toInt())}$unit',
          onDone: (v) => send(f.code, v.round()),
        );
      case 'Json':
        if (f.code.startsWith('colour_data')) return _colorBlock(f);
        return const SizedBox.shrink();
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _colorBlock(DeviceFunction f) {
    final v2 = f.code.endsWith('v2');
    final maxSv = v2 ? 1000 : 255;
    const hues = [0, 30, 55, 120, 180, 220, 270, 310];
    return _block(
      f,
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (final h in hues)
          GestureDetector(
            onTap: () async {
              if (funcs.any((e) => e.code == 'work_mode')) await send('work_mode', 'colour');
              send(f.code, jsonEncode({'h': h, 's': maxSv, 'v': maxSv}));
            },
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: HSVColor.fromAHSV(1, h.toDouble(), 1, 1).toColor(),
                shape: BoxShape.circle,
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant, width: 2),
              ),
            ),
          ),
      ]),
    );
  }

  Widget _block(DeviceFunction f, Widget child) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(iconFor(f.code), size: 18, color: Theme.of(context).colorScheme.onSurfaceVariant),
          const SizedBox(width: 8),
          Text(labelFor(f), style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 10),
        child,
      ]),
    );
  }
}

class _IntSlider extends StatefulWidget {
  final String title;
  final IconData icon;
  final double min, max, value;
  final int? divisions;
  final String Function(double) format;
  final ValueChanged<double> onDone;
  const _IntSlider({
    super.key,
    required this.title,
    required this.icon,
    required this.min,
    required this.max,
    required this.value,
    required this.divisions,
    required this.format,
    required this.onDone,
  });

  @override
  State<_IntSlider> createState() => _IntSliderState();
}

class _IntSliderState extends State<_IntSlider> {
  late double v = widget.value;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Column(children: [
        Row(children: [
          Icon(widget.icon, size: 18, color: cs.onSurfaceVariant),
          const SizedBox(width: 8),
          Expanded(child: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w600))),
          Text(widget.format(v), style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700)),
        ]),
        Slider(
          min: widget.min,
          max: widget.max,
          divisions: widget.divisions,
          value: v.clamp(widget.min, widget.max),
          onChanged: (x) => setState(() => v = x),
          onChangeEnd: widget.onDone,
        ),
      ]),
    );
  }
}
