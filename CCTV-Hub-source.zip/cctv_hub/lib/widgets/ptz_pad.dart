import 'package:flutter/material.dart';

/// D-pad PTZ: tahan untuk menggerakkan, lepas untuk berhenti.
class PtzPad extends StatelessWidget {
  final void Function(int dx, int dy) onMove;
  final VoidCallback onStop;
  final void Function(int dir)? onZoom;
  const PtzPad({super.key, required this.onMove, required this.onStop, this.onZoom});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget arrow(IconData icon, int dx, int dy, Alignment a) => Align(
          alignment: a,
          child: _HoldButton(
            onDown: () => onMove(dx, dy),
            onUp: onStop,
            child: Icon(icon, size: 30, color: cs.onSurface),
          ),
        );

    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        width: 190,
        height: 190,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: cs.surfaceContainer,
          border: Border.all(color: cs.outlineVariant),
        ),
        child: Stack(children: [
          arrow(Icons.keyboard_arrow_up_rounded, 0, 1, Alignment.topCenter),
          arrow(Icons.keyboard_arrow_down_rounded, 0, -1, Alignment.bottomCenter),
          arrow(Icons.keyboard_arrow_left_rounded, -1, 0, Alignment.centerLeft),
          arrow(Icons.keyboard_arrow_right_rounded, 1, 0, Alignment.centerRight),
          Center(
            child: Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: cs.surfaceContainerLow,
                border: Border.all(color: cs.outlineVariant),
              ),
              child: Icon(Icons.control_camera_rounded, color: cs.primary),
            ),
          ),
        ]),
      ),
      if (onZoom != null) ...[
        const SizedBox(width: 24),
        Column(mainAxisSize: MainAxisSize.min, children: [
          _HoldButton(
            onDown: () => onZoom!(1),
            onUp: onStop,
            boxed: true,
            child: const Icon(Icons.zoom_in_rounded),
          ),
          const SizedBox(height: 12),
          _HoldButton(
            onDown: () => onZoom!(-1),
            onUp: onStop,
            boxed: true,
            child: const Icon(Icons.zoom_out_rounded),
          ),
        ]),
      ],
    ]);
  }
}

class _HoldButton extends StatefulWidget {
  final VoidCallback onDown;
  final VoidCallback onUp;
  final Widget child;
  final bool boxed;
  const _HoldButton(
      {required this.onDown, required this.onUp, required this.child, this.boxed = false});

  @override
  State<_HoldButton> createState() => _HoldButtonState();
}

class _HoldButtonState extends State<_HoldButton> {
  bool pressed = false;

  void _set(bool v) {
    if (pressed == v) return;
    setState(() => pressed = v);
    v ? widget.onDown() : widget.onUp();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Listener(
      onPointerDown: (_) => _set(true),
      onPointerUp: (_) => _set(false),
      onPointerCancel: (_) => _set(false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          shape: widget.boxed ? BoxShape.rectangle : BoxShape.circle,
          borderRadius: widget.boxed ? BorderRadius.circular(16) : null,
          color: pressed
              ? cs.primary.withValues(alpha: 0.22)
              : (widget.boxed ? cs.surfaceContainer : Colors.transparent),
          border: widget.boxed ? Border.all(color: cs.outlineVariant) : null,
        ),
        alignment: Alignment.center,
        child: widget.child,
      ),
    );
  }
}
