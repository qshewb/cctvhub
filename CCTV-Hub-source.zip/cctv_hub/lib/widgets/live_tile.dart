import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';

import '../brands.dart';
import '../models.dart';
import '../services/stream.dart';
import '../store.dart';
import 'common.dart';

/// Kartu kamera di grid. Menampilkan preview langsung (substream, tanpa suara).
class LiveTile extends StatefulWidget {
  final Device device;
  final bool live;
  final VoidCallback onTap;
  const LiveTile({super.key, required this.device, required this.live, required this.onTap});

  @override
  State<LiveTile> createState() => _LiveTileState();
}

class _LiveTileState extends State<LiveTile> {
  Player? _player;
  VideoController? _ctrl;
  String? _error;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    if (widget.live) _start();
  }

  @override
  void didUpdateWidget(covariant LiveTile old) {
    super.didUpdateWidget(old);
    if (widget.live && _player == null) _start();
    if (!widget.live && _player != null) _stop();
  }

  Future<void> _start() async {
    setState(() => _error = null);
    final p = Player();
    _player = p;
    _ctrl = VideoController(p);
    await tunePlayer(p);
    await p.setVolume(0);
    p.stream.playing.listen((v) {
      if (mounted) setState(() => _playing = v);
    });
    p.stream.error.listen((e) {
      if (mounted) setState(() => _error = 'Gagal memuat');
    });
    try {
      final url = await resolveStream(context.read<AppStore>(), widget.device, sub: true);
      if (!mounted || _player != p) return;
      await p.open(Media(url));
    } catch (e) {
      if (mounted) setState(() => _error = 'Offline');
    }
  }

  void _stop() {
    _player?.dispose();
    _player = null;
    _ctrl = null;
    _playing = false;
  }

  @override
  void dispose() {
    _player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final store = context.watch<AppStore>();
    final acc = store.account(widget.device.accountId);
    final brand = brandById(acc?.brandId ?? 'generic');
    final fav = store.favorites.contains(widget.device.id);

    return GestureDetector(
      onTap: widget.onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Container(
          color: const Color(0xFF0B0D10),
          child: Stack(fit: StackFit.expand, children: [
            if (_ctrl != null)
              Video(controller: _ctrl!, controls: NoVideoControls, fit: BoxFit.cover),
            if (_ctrl == null || (!_playing && _error == null))
              Center(
                child: widget.live
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white54))
                    : const Icon(Icons.play_circle_outline_rounded,
                        color: Colors.white54, size: 36),
              ),
            if (_error != null)
              Center(
                child: TextButton.icon(
                  onPressed: () {
                    _stop();
                    _start();
                  },
                  icon: const Icon(Icons.refresh_rounded, color: Colors.white70, size: 18),
                  label: Text(_error!, style: const TextStyle(color: Colors.white70)),
                ),
              ),
            // gradasi bawah
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 18, 10, 8),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Color(0xCC000000), Color(0x00000000)],
                  ),
                ),
                child: Row(children: [
                  StatusDot(widget.device.online),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(widget.device.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                  ),
                  if (fav) const Icon(Icons.star_rounded, color: Color(0xFFFBBF24), size: 16),
                ]),
              ),
            ),
            Positioned(
              top: 8,
              left: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.45),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(brand.name,
                    style: TextStyle(
                        color: Color.lerp(brand.color, Colors.white, 0.4),
                        fontSize: 10,
                        fontWeight: FontWeight.w700)),
              ),
            ),
            if (_playing)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                      color: cs.error, borderRadius: BorderRadius.circular(6)),
                  child: const Text('LIVE',
                      style: TextStyle(
                          color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
