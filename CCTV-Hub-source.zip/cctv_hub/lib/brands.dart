import 'package:flutter/material.dart';
import 'models.dart';

/// Preset merek. Merek berbasis Tuya memakai Tuya Cloud,
/// merek lain memakai RTSP/ONVIF lokal dengan preset jalur stream.
class Brand {
  final String id;
  final String name;
  final Color color;
  final List<ConnType> methods;
  final int rtspPort;
  final int onvifPort;
  final String mainPath;
  final String subPath;
  final String defaultUser;
  final String hint;

  const Brand({
    required this.id,
    required this.name,
    required this.color,
    required this.methods,
    this.rtspPort = 554,
    this.onvifPort = 80,
    this.mainPath = '/',
    this.subPath = '',
    this.defaultUser = 'admin',
    this.hint = '',
  });

  String get initials =>
      name.split(' ').map((e) => e.isEmpty ? '' : e[0]).take(2).join().toUpperCase();
}

const brands = <Brand>[
  Brand(
    id: 'bardi',
    name: 'Bardi',
    color: Color(0xFF2E7DF6),
    methods: [ConnType.tuya],
    hint:
        'Bardi berbasis platform Tuya. Tautkan akun Bardi/Smart Life ke proyek Tuya IoT Cloud, lalu isi Access ID & Secret.',
  ),
  Brand(
    id: 'smartlife',
    name: 'Smart Life / Tuya',
    color: Color(0xFFFF6A3D),
    methods: [ConnType.tuya],
    hint: 'Semua perangkat Tuya (kamera, lampu, stopkontak, sensor, dll).',
  ),
  Brand(
    id: 'yoosee',
    name: 'Yoosee',
    color: Color(0xFF00B37E),
    methods: [ConnType.local],
    onvifPort: 5000,
    mainPath: '/onvif1',
    subPath: '/onvif2',
    hint:
        'User: admin. Password = password perangkat di aplikasi Yoosee (bukan password akun). Aktifkan NVR/ONVIF bila diminta.',
  ),
  Brand(
    id: 'v380',
    name: 'V380',
    color: Color(0xFF7B5CFF),
    methods: [ConnType.local],
    onvifPort: 8899,
    mainPath: '/live/ch00_0',
    subPath: '/live/ch00_1',
    hint:
        'Aktifkan RTSP/ONVIF di aplikasi V380 (Pengaturan perangkat). User & password sesuai yang Anda buat di sana.',
  ),
  Brand(
    id: 'eyesec',
    name: 'Eyesec',
    color: Color(0xFFE5484D),
    methods: [ConnType.tuya, ConnType.local],
    hint:
        'Jika kamera Eyesec Anda bisa ditambahkan ke Smart Life, pilih Tuya Cloud. Jika tidak, pakai RTSP/ONVIF lokal.',
  ),
  Brand(
    id: 'hikvision',
    name: 'Hikvision / Hilook',
    color: Color(0xFFD7263D),
    methods: [ConnType.local],
    mainPath: '/Streaming/Channels/101',
    subPath: '/Streaming/Channels/102',
  ),
  Brand(
    id: 'dahua',
    name: 'Dahua / Imou',
    color: Color(0xFF1F6FEB),
    methods: [ConnType.local],
    mainPath: '/cam/realmonitor?channel=1&subtype=0',
    subPath: '/cam/realmonitor?channel=1&subtype=1',
  ),
  Brand(
    id: 'ezviz',
    name: 'EZVIZ',
    color: Color(0xFF0FA3B1),
    methods: [ConnType.local],
    mainPath: '/h264/ch1/main/av_stream',
    subPath: '/h264/ch1/sub/av_stream',
    hint: 'User: admin, password = Verification Code di stiker kamera. Aktifkan RTSP di EZVIZ.',
  ),
  Brand(
    id: 'generic',
    name: 'Lainnya (ONVIF/RTSP)',
    color: Color(0xFF6B7280),
    methods: [ConnType.local],
    hint: 'Kamera apa pun yang mendukung ONVIF atau RTSP.',
  ),
];

Brand brandById(String id) =>
    brands.firstWhere((b) => b.id == id, orElse: () => brands.last);

const tuyaRegions = <String, String>{
  'sg': 'Singapura (Asia)',
  'us': 'Amerika Barat',
  'ue': 'Amerika Timur',
  'eu': 'Eropa Tengah',
  'we': 'Eropa Barat',
  'in': 'India',
  'cn': 'Tiongkok',
};
