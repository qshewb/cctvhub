import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'services/tuya.dart';

class AppStore extends ChangeNotifier {
  static const _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  List<Account> accounts = [];
  List<Device> devices = [];
  Map<String, String> errors = {}; // accountId -> pesan
  bool loading = false;

  ThemeMode themeMode = ThemeMode.system;
  int accent = 0;
  int gridColumns = 2;
  bool livePreview = true;
  Set<String> favorites = {};

  final Map<String, TuyaClient> _tuya = {};

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values[p.getInt('theme') ?? 0];
    accent = p.getInt('accent') ?? 0;
    gridColumns = p.getInt('cols') ?? 2;
    livePreview = p.getBool('live') ?? true;
    favorites = (p.getStringList('fav') ?? []).toSet();
    try {
      final raw = await _secure.read(key: 'accounts');
      if (raw != null) {
        accounts = (jsonDecode(raw) as List).map((e) => Account.fromJson(e)).toList();
      }
    } catch (_) {}
    notifyListeners();
    refresh();
  }

  Future<void> _savePrefs() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('theme', themeMode.index);
    await p.setInt('accent', accent);
    await p.setInt('cols', gridColumns);
    await p.setBool('live', livePreview);
    await p.setStringList('fav', favorites.toList());
  }

  Future<void> _saveAccounts() async {
    await _secure.write(
        key: 'accounts', value: jsonEncode(accounts.map((a) => a.toJson()).toList()));
  }

  void setTheme(ThemeMode m) {
    themeMode = m;
    _savePrefs();
    notifyListeners();
  }

  void setAccent(int i) {
    accent = i;
    _savePrefs();
    notifyListeners();
  }

  void setColumns(int c) {
    gridColumns = c;
    _savePrefs();
    notifyListeners();
  }

  void setLivePreview(bool v) {
    livePreview = v;
    _savePrefs();
    notifyListeners();
  }

  void toggleFavorite(String id) {
    favorites.contains(id) ? favorites.remove(id) : favorites.add(id);
    _savePrefs();
    notifyListeners();
  }

  TuyaClient tuya(String accountId) {
    final a = accounts.firstWhere((e) => e.id == accountId);
    return _tuya.putIfAbsent(accountId, () => TuyaClient(a));
  }

  Account? account(String id) {
    for (final a in accounts) {
      if (a.id == id) return a;
    }
    return null;
  }

  Future<void> upsertAccount(Account a) async {
    final i = accounts.indexWhere((e) => e.id == a.id);
    i >= 0 ? accounts[i] = a : accounts.add(a);
    _tuya.remove(a.id);
    await _saveAccounts();
    await refresh();
  }

  Future<void> removeAccount(String id) async {
    accounts.removeWhere((e) => e.id == id);
    _tuya.remove(id);
    errors.remove(id);
    await _saveAccounts();
    await refresh();
  }

  Future<void> saveCamera(String accountId, LocalCamera cam) async {
    final a = account(accountId);
    if (a == null) return;
    final i = a.cameras.indexWhere((c) => c.id == cam.id);
    i >= 0 ? a.cameras[i] = cam : a.cameras.add(cam);
    await _saveAccounts();
    await refresh();
  }

  Future<void> removeCamera(String accountId, String camId) async {
    account(accountId)?.cameras.removeWhere((c) => c.id == camId);
    await _saveAccounts();
    await refresh();
  }

  Future<void> persist() => _saveAccounts();

  Future<void> refresh() async {
    loading = true;
    notifyListeners();
    final all = <Device>[];
    errors = {};
    await Future.wait(accounts.map((a) async {
      if (a.type == ConnType.local) {
        for (final c in a.cameras) {
          all.add(Device(
              id: c.id, accountId: a.id, name: c.name, category: 'local', online: true, local: c));
        }
      } else {
        try {
          all.addAll(await tuya(a.id).devices(a.id));
        } catch (e) {
          errors[a.id] = e.toString();
        }
      }
    }));
    all.sort((x, y) {
      final fx = favorites.contains(x.id) ? 0 : 1;
      final fy = favorites.contains(y.id) ? 0 : 1;
      return fx != fy ? fx - fy : x.name.toLowerCase().compareTo(y.name.toLowerCase());
    });
    devices = all;
    loading = false;
    notifyListeners();
  }

  List<Device> get cameras => devices.where((d) => d.isCamera).toList();
  List<Device> get smartDevices => devices.where((d) => !d.isCamera).toList();
}
