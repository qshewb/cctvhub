# CCTV Hub

Satu aplikasi Android untuk banyak akun CCTV & perangkat pintar: Bardi, Smart Life/Tuya, Yoosee, V380, Eyesec, Hikvision, Dahua/Imou, EZVIZ, dan kamera ONVIF/RTSP lain.

## Fitur
- **Multi-akun**: gabungkan banyak akun & merek, semua kamera tampil dalam satu grid.
- **Live view** grid 1/2/3 kolom + layar penuh landscape, HD/SD, suara on/off.
- **Snapshot & rekam** video langsung ke galeri di dalam aplikasi.
- **PTZ** (gerak kamera + zoom + 4 posisi preset) untuk kamera ONVIF, dan PTZ untuk kamera Tuya/Bardi.
- **Fitur bawaan otomatis** untuk perangkat Tuya/Bardi: aplikasi membaca spesifikasi tiap perangkat, jadi semua fitur bawaannya muncul sendiri (penglihatan malam, deteksi gerak, sirene, rekam SD, mode privasi, lampu, kecerahan, warna, stopkontak, timer, dll).
- **Perangkat pintar**: lampu, stopkontak, saklar, sensor, tirai — tombol daya cepat + halaman kontrol lengkap.
- **Mode Terang / Gelap / Otomatis** + 5 warna aksen.
- Kredensial disimpan **terenkripsi** di HP.

## Cara mendapatkan APK (tanpa install apa pun di komputer)
1. Buat akun di **github.com** (gratis), lalu **New repository** (boleh Private).
2. Klik **uploading an existing file**, lalu seret **seluruh isi** folder ini (termasuk folder `.github`). Klik **Commit changes**.
   - Jika folder `.github` tidak ikut terunggah, buat file baru bernama `.github/workflows/build-apk.yml` dan tempel isinya.
3. Buka tab **Actions** → workflow **Build APK** berjalan otomatis (±10–15 menit).
4. Setelah centang hijau, buka run tersebut → bagian **Artifacts** → unduh **CCTV-Hub-APK** (zip).
5. Di dalam zip:
   - `app-arm64-v8a-release.apk` → untuk hampir semua HP Android modern (paling kecil).
   - `app-release.apk` → versi universal (cocok untuk semua HP).
6. Pasang di HP (izinkan "Instal dari sumber tidak dikenal").

Alternatif dengan komputer: install Flutter, lalu jalankan
```
flutter create --platforms=android --org com.cctvhub --project-name cctv_hub .
cp tool/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter build apk --release
```

## Menghubungkan akun

### Bardi / Smart Life / Tuya (cloud)
Bardi berjalan di atas platform Tuya. Aplikasi pihak ketiga tidak bisa login memakai email & password Bardi secara langsung, jadi koneksinya lewat **Tuya IoT Cloud** (resmi, gratis):
1. Daftar di **iot.tuya.com** → Cloud → Development → **Create Cloud Project** (Smart Home, pilih pusat data yang sama dengan akun aplikasi Anda).
2. Tab **Service API**: aktifkan *IoT Core*, *Authorization Token Management*, dan *IoT Video Live Stream* (untuk kamera).
3. Tab **Devices → Link App Account** → scan QR dengan aplikasi **Smart Life**. Perangkat Bardi bisa ditambahkan ke Smart Life lebih dulu.
4. Salin **Access ID** dan **Access Secret** ke aplikasi (Akun → Tambah akun → Bardi).

### Yoosee, V380, Eyesec, Hikvision, Dahua, EZVIZ, dll (lokal)
Pilih merek → isi IP kamera, username, password → **Tes koneksi**. Jalur stream sudah diisi otomatis sesuai merek, atau dideteksi lewat ONVIF.

| Merek | Port ONVIF | Jalur HD | Catatan |
|---|---|---|---|
| Yoosee | 5000 | `/onvif1` | user `admin`, password = password perangkat |
| V380 | 8899 | `/live/ch00_0` | aktifkan RTSP/ONVIF di aplikasi V380 |
| Hikvision | 80 | `/Streaming/Channels/101` | |
| Dahua/Imou | 80 | `/cam/realmonitor?channel=1&subtype=0` | |
| EZVIZ | 80 | `/h264/ch1/main/av_stream` | password = verification code |

Akses dari luar rumah: gunakan IP publik/DDNS + port forwarding di router, atau VPN (mis. Tailscale/ZeroTier) — lebih aman.

## Batasan yang perlu diketahui
- Akun cloud **Yoosee, V380, dan Eyesec** bersifat tertutup (tidak ada API publik), jadi kamera tersebut dihubungkan secara lokal lewat RTSP/ONVIF, bukan login akun.
- Fitur yang hanya ada di cloud masing-masing pabrikan (push notifikasi gerakan, playback cloud/kartu SD dari jarak jauh, bicara dua arah) tidak tersedia lewat jalur terbuka ini.
- Live stream kamera Tuya bergantung pada layanan *IoT Video Live Stream* di proyek Tuya Anda.

## Struktur kode
```
lib/
  main.dart                 navigasi utama & tema
  theme.dart                desain terang/gelap
  brands.dart               preset merek
  models.dart, store.dart   data & penyimpanan
  services/tuya.dart        Tuya OpenAPI (token, perangkat, perintah, stream)
  services/onvif.dart       ONVIF (stream, PTZ, preset)
  services/stream.dart      pemilih URL stream & pengaturan player
  screens/                  layar Kamera, Perangkat, Akun, Setelan, Galeri
  widgets/                  kartu live, kontrol dinamis, D-pad PTZ
```
